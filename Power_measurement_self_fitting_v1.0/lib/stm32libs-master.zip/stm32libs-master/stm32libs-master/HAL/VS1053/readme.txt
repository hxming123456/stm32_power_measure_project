Library for VS1053 audio codec.
Later will be available documentation.